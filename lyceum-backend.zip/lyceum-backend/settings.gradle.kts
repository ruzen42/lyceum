rootProject.name = "lyceum-backend"
