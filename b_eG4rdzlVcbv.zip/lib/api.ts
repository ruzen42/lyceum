const API_BASE = "http://localhost:8080"

function getToken(): string | null {
  if (typeof window === "undefined") return null
  const stored = localStorage.getItem("lyceum_user")
  if (!stored) return null
  try {
    return JSON.parse(stored).token
  } catch {
    return null
  }
}

export async function apiFetch<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getToken()
  const headers: HeadersInit = {
    ...options.headers,
  }

  if (token) {
    ;(headers as Record<string, string>)["Authorization"] = `Bearer ${token}`
  }

  if (!(options.body instanceof FormData)) {
    ;(headers as Record<string, string>)["Content-Type"] = "application/json"
  }

  const res = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  })

  if (!res.ok) {
    const error = await res.text()
    throw new Error(error || `Request failed with status ${res.status}`)
  }

  const contentType = res.headers.get("content-type")
  if (contentType && contentType.includes("application/json")) {
    return res.json()
  }
  return res.text() as unknown as T
}

export async function apiFormData<T>(
  endpoint: string,
  formData: FormData
): Promise<T> {
  const token = getToken()
  const headers: HeadersInit = {}

  if (token) {
    headers["Authorization"] = `Bearer ${token}`
  }

  const res = await fetch(`${API_BASE}${endpoint}`, {
    method: "POST",
    headers,
    body: formData,
  })

  if (!res.ok) {
    const error = await res.text()
    throw new Error(error || `Request failed with status ${res.status}`)
  }

  const contentType = res.headers.get("content-type")
  if (contentType && contentType.includes("application/json")) {
    return res.json()
  }
  return res.text() as unknown as T
}

export function getHtmlUrl(type: "museum-exhibit" | "classroom", id: number): string {
  return `${API_BASE}/api/${type}/${id}/html`
}
